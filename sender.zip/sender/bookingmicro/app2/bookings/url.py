from django.urls import path
from . import views

urlpatterns=[
    path('doctorlist',views.doctorlist,name= 'doctorlist'),
    path('makebooking',views.makebooking,name = 'makebooking'),
    path('viewpatientbooking',views.viewpatientbooking,name = 'viewpatientbooking'),
    path('viewdoctorbooking',views.viewdoctorbooking,name = 'viewdoctorbooking'),
]