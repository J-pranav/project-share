from django.shortcuts import render
from django.http import HttpResponse
from .models import bookingdetails
from django.views.decorators.csrf import csrf_exempt

import jwt,datetime
from rest_framework.exceptions import AuthenticationFailed

import requests
import json

k ={'bookingsecret' : "doctorsecret"}

def doctorlist(request):
    docs = requests.post("http://127.0.0.1:8003/doctormainapp/displaydoc",data = k)
    d = docs.json()
    return HttpResponse(docs)

@csrf_exempt 
def makebooking(request):
    flag=0
    slots =[]

    if(request.method !='POST'):
        return HttpResponse("not post request")

    newcurrentpat = request.POST['patname']

    # daten= datetime.date.today()
    if(request.POST['bookingsecret'] == 'doctorsecret'):
        booked = bookingdetails.objects.all()
        if('datepat' in request.POST):
           
            slots =[]
            global daten
            global namen
            daten = request.POST['datepat']
            namen = request.POST['namepat']
            for i in range(1,5):
                print(i)
                for j in booked:
                    # print(j.doctorid == id , str(j.date) == daten , j.slotnumber == i)
                    if(j.doctorid == id and str(j.date) == daten and j.slotnumber == i):
                        flag+=1
                        print("flag:",flag)
                if(flag ==0):
                    slots.append(i)
                flag=0
            
            return HttpResponse(slots)
        else:
            k = {'bookingsecret' : "doctorsecret","id": request.POST["id"]}
            dummycurrentdoc = requests.post("http://127.0.0.1:8003/doctormainapp/displaydoc",data = k)
            dummycurrentdoc = dummycurrentdoc.json()
            newcurrentdoc = dummycurrentdoc[str(request.POST["id"])]

            newbook = bookingdetails(booker = newcurrentpat, doctorid = int(request.POST["id"]),patientid = request.POST['patid'], doctorname = newcurrentdoc, 
            patientname = namen, date = daten ,slotnumber = request.POST['slotpat'])
            newbook.save()
            return HttpResponse("booked")

    return HttpResponse("not from patient")

@csrf_exempt 
def viewpatientbooking(request):

    patdict ={}
    if(request.POST['bookingsecret'] == 'doctorsecret'):  
        if('id' in request.POST):
            iterpat = bookingdetails.objects.filter(patientid = request.POST['id'])
            flag =0
            for i in iterpat:
                patdict[i.booker+str(flag)] = [i.doctorname,i.patientname,str(i.date),i.slotnumber]
                flag+=1

        return HttpResponse(json.dumps(patdict))
    else:
        return HttpResponse('who r u')

@csrf_exempt 
def viewdoctorbooking(request):

    docdict ={}
    if(request.POST['bookingsecret'] == 'doctorsecret'):  
        if('id' in request.POST):
            iterdoc = bookingdetails.objects.filter(doctorid = request.POST['id'])
            flag =0
            for i in iterdoc:
                docdict[i.doctorname+str(flag)] = [i.booker,i.patientname,str(i.date),i.slotnumber]
                flag+=1

        return HttpResponse(json.dumps(docdict))
    else:
        return HttpResponse('who r u')
