from django.db import models

class bookingdetails(models.Model):
    booker = models.CharField(max_length = 100)
    doctorid = models.IntegerField(null=True)
    patientid = models.IntegerField(null=True)
    doctorname = models.CharField(max_length = 100)
    patientname = models.CharField(max_length = 100)
    date = models.DateField(null=True)
    slotnumber = models.IntegerField(null=True)
