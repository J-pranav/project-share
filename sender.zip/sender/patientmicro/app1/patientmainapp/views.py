from django.shortcuts import render
from .models import patients
from django.views.decorators.csrf import csrf_exempt

from django.forms import modelform_factory

from django.http import HttpResponse
from rest_framework.exceptions import AuthenticationFailed
import jwt,datetime
import json
import requests

patientaddform = modelform_factory(patients,fields =['name','password','age','gender','address','emailaddress'])

@csrf_exempt 
def signup(request):
    if (request.method =='POST'):
        # return HttpResponse("added")
        form = patientaddform(request.POST)
        if(form.is_valid()):
            form.save()
            return HttpResponse("added")
    else:
        return HttpResponse("invalid form")
    

patientloginform = modelform_factory(patients,fields =['name','password'])

@csrf_exempt 
def patientlogin(request):
        
    iterpatient = patients.objects.all()

    if(request.method == 'POST'):
        form = patientloginform(request.POST)
        if(form.is_valid()):

            iterpat = patients.objects.filter(name = form['name'].value()).first()

            if iterpat is None:
                raise AuthenticationFailed("User not found")

            if(iterpat.password != form['password'].value()):
                raise AuthenticationFailed("Wrong Password")

            elif(iterpat.password == form['password'].value()):

                patpayload ={
                    'id': iterpat.id,
                    'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=60),
                    'iat': datetime.datetime.utcnow(),
                }  
                
                pattoken = jwt.encode(patpayload,'secret',algorithm = 'HS256')
                
                res = HttpResponse('patient logged in')
                res.set_cookie(key='jwt2', value= pattoken, httponly=True)

                return res
    else:
        return HttpResponse("invalid form")

@csrf_exempt    
def displaypat(request):

    patdict ={}
    if(request.POST['bookingsecret'] == 'doctorsecret'):  
        if('id' in request.POST):
            iterpat = patients.objects.filter(id  = request.POST['id'])
            patdict[iterpat[0].id] = iterpat[0].name
        else: 
            iterpat = patients.objects.values('name', 'id')
            for i in iterpat:
                patdict[i['id']] = i['name']
        
        return HttpResponse(json.dumps(patdict))
    else:
        return HttpResponse('who r u')

def displaypatientbooking(request):
    pattoken = request.COOKIES.get('jwt2')
    
    if not pattoken:
        raise AuthenticationFailed("Unauthenticated1")
    try:
        payload = jwt.decode(pattoken,'secret',algorithms = ['HS256'])
    except jwt.ExpiredSignatureError:
        raise AuthenticationFailed("Unauthenticated2")

    k ={'bookingsecret' : "doctorsecret","id":payload['id']}

    dummycurrentpat = requests.post("http://127.0.0.1:8002/bookings/viewpatientbooking",data = k)
    currentpatbookings = dummycurrentpat.json()

    return HttpResponse(dummycurrentpat)

def logout(request):

    res = HttpResponse("patient logged out")
    res.delete_cookie('jwt2')

    return res

@csrf_exempt
def make_booking_pat(request,id):

    pattoken = request.COOKIES.get('jwt2')
    
    if not pattoken:
        raise AuthenticationFailed("Unauthenticated1")
    try:
        payload = jwt.decode(pattoken,'secret',algorithms = ['HS256'])
    except jwt.ExpiredSignatureError:
        raise AuthenticationFailed("Unauthenticated2")

    patuse = patients.objects.filter(id  = payload['id'])

    k ={'bookingsecret' : "doctorsecret","id": id,"patname": patuse[0].name,"patid": patuse[0].id}

    if('date' in request.POST):
        k['datepat'] = request.POST['date']
        k['namepat'] = request.POST['namen']
    else:
        k['slotpat'] = request.POST['slot']
        print("\n\n",k)

    hello = requests.post("http://127.0.0.1:8002/bookings/makebooking", data = k)

    return HttpResponse(hello)