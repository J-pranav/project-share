from django.db import models

class patients(models.Model):
    name = models.CharField(max_length = 100)
    age = models.IntegerField(default = name,null=True)
    password = models.CharField(max_length = 20)
    gender =  models.CharField(max_length = 1)
    emailaddress = models.EmailField(max_length = 100)
    address = models.TextField(max_length = 200)

