from django.shortcuts import render
from django.http import HttpResponse
from .models import bookingdetails
from django.views.decorators.csrf import csrf_exempt

import jwt,datetime
from rest_framework.exceptions import AuthenticationFailed

import requests
import json

k ={'bookingsecret' : "doctorsecret"}

def doctorlist(request):
    docs = requests.post("http://127.0.0.1:8003/doctormainapp/displaydoc",data = k)
    d = docs.json()
    return HttpResponse(docs)

@csrf_exempt 
def makebooking(request,id):
    flag=0
    slots =[]

    pattoken = request.COOKIES.get('jwt2')
    print("\ncookes:",request.COOKIES.keys())
    
    if not pattoken:
        raise AuthenticationFailed("Unauthenticated1")
    try:
        payload = jwt.decode(pattoken,'secret',algorithms = ['HS256'])
    except jwt.ExpiredSignatureError:
        raise AuthenticationFailed("Unauthenticated2")

    k = {'bookingsecret' : "doctorsecret","id": payload['id']}
    dummycurrentpat = requests.post("http://127.0.0.1:8001/patientmainapp/displaypat",data = k)
    dummycurrentpat = dummycurrentpat.json()
    newcurrentpat = dummycurrentpat[str(payload['id'])]

    # daten= datetime.date.today()
    if(request.method =="POST"):
        booked = bookingdetails.objects.all()
        if('date' in request.POST):
           
            slots =[]
            global daten
            global namen
            daten = request.POST['date']
            namen = request.POST['namen']
            for i in range(1,5):
                print(i)
                for j in booked:
                    print(j.doctorid == id , str(j.date) == daten , j.slotnumber == i)
                    if(j.doctorid == id and str(j.date) == daten and j.slotnumber == i):
                        flag+=1
                        print("flag:",flag)
                if(flag ==0):
                    slots.append(i)
                flag=0
            # slots =temp
        else:
            k = {'bookingsecret' : "doctorsecret","id": id}
            dummycurrentdoc = requests.post("http://127.0.0.1:8003/doctormainapp/displaydoc",data = k)
            dummycurrentdoc = dummycurrentdoc.json()
            newcurrentdoc = dummycurrentdoc[str(id)]

            newbook = bookingdetails(booker = newcurrentpat, doctorid = id,patientid = payload['id'], doctorname = newcurrentdoc, 
            patientname = namen, date = daten ,slotnumber = request.POST['slot'])
            newbook.save()
            return HttpResponse("booked")

    return HttpResponse(slots)

@csrf_exempt 
def viewpatientbooking(request):

    patdict ={}
    if(request.POST['bookingsecret'] == 'doctorsecret'):  
        if('id' in request.POST):
            iterpat = bookingdetails.objects.filter(patientid = request.POST['id'])
            flag =0
            for i in iterpat:
                patdict[i.booker+str(flag)] = [i.doctorname,i.patientname,str(i.date),i.slotnumber]
                flag+=1

        return HttpResponse(json.dumps(patdict))
    else:
        return HttpResponse('who r u')

@csrf_exempt 
def viewdoctorbooking(request):

    docdict ={}
    if(request.POST['bookingsecret'] == 'doctorsecret'):  
        if('id' in request.POST):
            iterdoc = bookingdetails.objects.filter(doctorid = request.POST['id'])
            flag =0
            for i in iterdoc:
                docdict[i.doctorname+str(flag)] = [i.booker,i.patientname,str(i.date),i.slotnumber]
                flag+=1

        return HttpResponse(json.dumps(docdict))
    else:
        return HttpResponse('who r u')
