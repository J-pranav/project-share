from django.contrib import admin
from doctormainapp.models import doctors
# Register your models here.

admin.site.register(doctors)