from django.db import models

class doctors(models.Model):
    name = models.CharField(max_length = 100)
    specilization = models.CharField(max_length = 100)
    # photo = models.ImageField(null = True)
    password = models.CharField(max_length = 20)
    slots = models.IntegerField(null=True)