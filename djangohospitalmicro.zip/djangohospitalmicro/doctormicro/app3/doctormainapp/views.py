from django.shortcuts import render
from .models import doctors

from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt

from rest_framework.exceptions import AuthenticationFailed
import jwt,datetime

import requests
import json
from django.forms import modelform_factory

@csrf_exempt 
def displaydoc(request):
    docdict ={}
    # print(request.POST)
    if(request.POST['bookingsecret'] == 'doctorsecret'):  
        if('id' in request.POST):
            iterdoc = doctors.objects.filter(id = request.POST['id'])
            docdict[iterdoc[0].id] = iterdoc[0].name
        else: 
            iterdoc = doctors.objects.values('name', 'id')
            for i in iterdoc:
                docdict[i['id']] = i['name']
        
        return HttpResponse(json.dumps(docdict))
    else:
        return HttpResponse('who r u')

doctorloginform = modelform_factory(doctors,fields =['name','password'])

@csrf_exempt 
def doctorlogin(request):

    if(request.method == 'POST'):
        form = doctorloginform(request.POST)
        if(form.is_valid()):

            iterdoc = doctors.objects.filter(name = form['name'].value()).first()

            if iterdoc is None:
                raise AuthenticationFailed("User not found")

            if(iterdoc.password != form['password'].value()):
                raise AuthenticationFailed("Wrong Password")

            elif(iterdoc.password == form['password'].value()):

                docpayload ={
                    'id': iterdoc.id,
                    'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=60),
                    'iat': datetime.datetime.utcnow(),
                }  
                
                token = jwt.encode(docpayload, 'secret', algorithm='HS256')

                res = HttpResponse("doctor logged in")

                # response.set_cookie(key='wst', value= 1, httponly=True)

                # print('\nrdoctordcookie1: ',request.COOKIES.keys())

                
                res.set_cookie(key='jwt1', value= token, httponly=True)

                return res
    else:
        return HttpResponse("some  request error")


def displaydoctorbooking(request):
    
    doctoken = request.COOKIES.get('jwt1')
    
    if not doctoken:
        raise AuthenticationFailed("Unauthenticated1")
    try:
        payload = jwt.decode(doctoken,'secret',algorithms = ['HS256'])
    except jwt.ExpiredSignatureError:
        raise AuthenticationFailed("Unauthenticated2")

    k ={'bookingsecret' : "doctorsecret","id":payload['id']}

    dummycurrentdoc = requests.post("http://127.0.0.1:8002/bookings/viewdoctorbooking",data = k)
    #currentdocbookings = dummycurrentdoc.json()
    
    return HttpResponse(dummycurrentdoc)


def logout(request):

    res = HttpResponse("doctor logged out")
    res.delete_cookie('jwt1')

    return res