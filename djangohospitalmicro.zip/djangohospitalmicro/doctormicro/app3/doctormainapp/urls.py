from django.urls import path
from . import views

urlpatterns = [
    path('displaydoc',views.displaydoc,name='displaydoc'),
    path('doctorlogin',views.doctorlogin,name = 'doctorlogin'),
    path('displaydoctorbooking',views.displaydoctorbooking,name = 'displaydoctorbooking'),
    path('logout',views.logout,name='logout'),
]