from django.apps import AppConfig


class PatientmainappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'patientmainapp'
