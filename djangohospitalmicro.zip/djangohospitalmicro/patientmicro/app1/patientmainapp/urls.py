from django.urls import path
from . import views

urlpatterns=[
    path('signup',views.signup,name='signup'),
    path('patientlogin',views.patientlogin,name='patientlogin'),
    path('displaypat',views.displaypat,name='displaypat'),
    path('displaypatientbooking',views.displaypatientbooking,name='displaypatientbooking'),
    path('logout',views.logout,name='logout'),
]